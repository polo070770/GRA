#include "trajectoria.h"

trajectoria::trajectoria(vec4 plano, int sampling)
{
}

