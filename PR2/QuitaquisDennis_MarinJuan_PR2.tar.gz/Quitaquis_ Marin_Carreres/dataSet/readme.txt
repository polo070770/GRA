-- 3dvia.com   --

The zip file Ferrari F2007.3DS.zip contains the following files :
- readme.txt
- Ferrari F2007.3DS
- hub_blue.dds
- 5_wings.dds
- 5_BODY1.dds
- Wh_avt.dds
- Wh_arr.dds
- thread.dds
- Susp_Avt.dds
- Susp_Arr.dds
- hub_red.dds


-- Model information --

Model Name : Ferrari F2007
Author : Olivier-Thomas D'Ettorre
Publisher : tyio

You can view this model here :
http://www.3dvia.com/content/B53299ABBD8FA1B3
More models about this author :
http://www.3dvia.com/tyio


-- Attached license --

A license is attached to the Ferrari F2007 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial 2.5
Detailed license : http://creativecommons.org/licenses/by-nc/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
